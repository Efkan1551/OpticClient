package com.optic.client.mixin;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.renderer.LightmapRenderStateExtractor;
import net.minecraft.client.renderer.state.LightmapRenderState;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightmapRenderStateExtractor.class)
public abstract class LightmapRenderStateExtractorMixin {
	private static final Vector3fc OPTICCLIENT$FULL_BRIGHT_COLOR = new Vector3f(1.0f, 1.0f, 1.0f);

	@Inject(method = "extract", at = @At("RETURN"))
	private void opticclient$applyFullbright(LightmapRenderState state, float tickDelta, CallbackInfo callbackInfo) {
		if (ClientConfig.fullbright && state.needsUpdate) {
			state.ambientColor = OPTICCLIENT$FULL_BRIGHT_COLOR;
			state.darknessEffectScale = 0.0f;
			state.bossOverlayWorldDarkening = 0.0f;
		}
	}
}