package com.optic.client.mixin;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
	@Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true)
	private void opticclient$disableHurtCamera(CallbackInfo callbackInfo) {
		if (ClientConfig.noHurtCam) {
			callbackInfo.cancel();
		}
	}
}