package com.optic.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.optic.client.OpticClientMod;
import com.optic.client.hud.HudAnchor;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ClientConfig {
	public static final String[] HUD_PROFILE_NAMES = {"Minimal", "PvP", "Exploration"};
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("opticclient.json");
	private static final Path PROFILE_BACKUP_PATH = FabricLoader.getInstance().getConfigDir().resolve("opticclient-profiles.json");

	public static boolean fullbright;
	public static boolean mainhandHud = true;
	public static boolean armorHud = true;
	public static boolean statusHud = true;
	public static boolean deathMarkerHud = true;
	public static boolean offhandHud;
	public static boolean potionHud = true;
	public static boolean suppliesHud = true;
	public static boolean hudLocked;
	public static boolean snapHudToGrid = true;
	public static boolean autoHudProfileByDimension;
	public static boolean toggleSprint;
	public static boolean noHurtCam;
	public static int durabilityWarningPercent = 20;
	public static int mainhandWarningPercent = 20;
	public static int offhandWarningPercent = 20;
	public static int helmetWarningPercent = 20;
	public static int chestplateWarningPercent = 20;
	public static int leggingsWarningPercent = 20;
	public static int bootsWarningPercent = 20;
	public static int notificationDurationSeconds = 4;
	public static boolean durabilityAlertsHeldItems = true;
	public static boolean durabilityAlertsArmor = true;
	public static HudAnchor notificationPosition = HudAnchor.TOP_RIGHT;
	public static PotionFilter potionFilter = PotionFilter.ALL;
	public static String trackedItemIds = "minecraft:totem_of_undying,minecraft:golden_apple";
	public static double gammaBeforeFullbright = 1.0;
	public static int accentColor = 0xFF62D6C8;
	public static String activeHudProfile = "Exploration";
	public static Map<String, HudProfile> hudProfiles = new LinkedHashMap<>();
	public static HudAnchor mainhandAnchor = HudAnchor.BOTTOM_RIGHT;
	public static HudAnchor armorAnchor = HudAnchor.BOTTOM_LEFT;
	public static HudAnchor statusAnchor = HudAnchor.TOP_LEFT;
	public static HudAnchor offhandAnchor = HudAnchor.BOTTOM_RIGHT;
	public static float mainhandHudX = -1.0f;
	public static float mainhandHudY = -1.0f;
	public static float mainhandHudScale = 1.0f;
	public static float mainhandHudOpacity = 0.72f;
	public static float armorHudX = -1.0f;
	public static float armorHudY = -1.0f;
	public static float armorHudScale = 1.0f;
	public static float armorHudOpacity = 0.72f;
	public static float statusHudX = -1.0f;
	public static float statusHudY = -1.0f;
	public static float statusHudScale = 1.0f;
	public static float statusHudOpacity = 0.72f;
	public static float offhandHudX = -1.0f;
	public static float offhandHudY = -1.0f;
	public static float offhandHudScale = 1.0f;
	public static float offhandHudOpacity = 0.72f;

	private ClientConfig() {
	}

	public static void load() {
		if (!Files.exists(CONFIG_PATH)) {
			return;
		}
		try {
			StoredConfig stored = GSON.fromJson(Files.readString(CONFIG_PATH), StoredConfig.class);
			if (stored == null) {
				return;
			}
			boolean hadHudProfiles = stored.hudProfiles != null && !stored.hudProfiles.isEmpty();
			fullbright = stored.fullbright;
			mainhandHud = stored.mainhandHud;
			armorHud = stored.armorHud;
			statusHud = stored.statusHud;
			deathMarkerHud = stored.deathMarkerHud;
			offhandHud = stored.offhandHud;
			potionHud = stored.potionHud;
			suppliesHud = stored.suppliesHud;
			hudLocked = stored.hudLocked;
			snapHudToGrid = stored.snapHudToGrid;
			autoHudProfileByDimension = stored.autoHudProfileByDimension;
			toggleSprint = stored.toggleSprint;
			noHurtCam = stored.noHurtCam;
			durabilityWarningPercent = stored.durabilityWarningPercent;
			mainhandWarningPercent = stored.mainhandWarningPercent;
			offhandWarningPercent = stored.offhandWarningPercent;
			helmetWarningPercent = stored.helmetWarningPercent;
			chestplateWarningPercent = stored.chestplateWarningPercent;
			leggingsWarningPercent = stored.leggingsWarningPercent;
			bootsWarningPercent = stored.bootsWarningPercent;
			notificationDurationSeconds = stored.notificationDurationSeconds;
			durabilityAlertsHeldItems = stored.durabilityAlertsHeldItems;
			durabilityAlertsArmor = stored.durabilityAlertsArmor;
			notificationPosition = stored.notificationPosition == null ? HudAnchor.TOP_RIGHT : stored.notificationPosition;
			potionFilter = stored.potionFilter == null ? PotionFilter.ALL : stored.potionFilter;
			trackedItemIds = stored.trackedItemIds == null ? "minecraft:totem_of_undying,minecraft:golden_apple" : stored.trackedItemIds;
			gammaBeforeFullbright = stored.gammaBeforeFullbright;
			accentColor = stored.accentColor;
			activeHudProfile = stored.activeHudProfile == null ? "Exploration" : stored.activeHudProfile;
			hudProfiles = stored.hudProfiles == null ? new LinkedHashMap<>() : stored.hudProfiles;
			mainhandAnchor = stored.mainhandAnchor == null ? HudAnchor.BOTTOM_RIGHT : stored.mainhandAnchor;
			armorAnchor = stored.armorAnchor == null ? HudAnchor.BOTTOM_LEFT : stored.armorAnchor;
			statusAnchor = stored.statusAnchor == null ? HudAnchor.TOP_LEFT : stored.statusAnchor;
			offhandAnchor = stored.offhandAnchor == null ? HudAnchor.BOTTOM_RIGHT : stored.offhandAnchor;
			mainhandHudX = stored.mainhandHudX;
			mainhandHudY = stored.mainhandHudY;
			mainhandHudScale = stored.mainhandHudScale;
			mainhandHudOpacity = stored.mainhandHudOpacity;
			armorHudX = stored.armorHudX;
			armorHudY = stored.armorHudY;
			armorHudScale = stored.armorHudScale;
			armorHudOpacity = stored.armorHudOpacity;
			statusHudX = stored.statusHudX;
			statusHudY = stored.statusHudY;
			statusHudScale = stored.statusHudScale;
			statusHudOpacity = stored.statusHudOpacity;
			offhandHudX = stored.offhandHudX;
			offhandHudY = stored.offhandHudY;
			offhandHudScale = stored.offhandHudScale;
			offhandHudOpacity = stored.offhandHudOpacity;
			ensureBuiltInProfiles();
			if (hadHudProfiles) {
				loadHudProfile(activeHudProfile);
			} else {
				activeHudProfile = "Exploration";
				saveHudProfile();
			}
			durabilityWarningPercent = Math.max(0, Math.min(100, durabilityWarningPercent));
			notificationDurationSeconds = Math.max(1, Math.min(15, notificationDurationSeconds));
		} catch (IOException | JsonParseException exception) {
			OpticClientMod.LOGGER.error("Could not read opticclient.json; using defaults", exception);
		}
	}

	public static void save() {
		ensureBuiltInProfiles();
		capture(hudProfiles.computeIfAbsent(activeHudProfile, ignored -> new HudProfile()));
		StoredConfig stored = new StoredConfig();
		stored.fullbright = fullbright;
		stored.mainhandHud = mainhandHud;
		stored.armorHud = armorHud;
		stored.statusHud = statusHud;
		stored.deathMarkerHud = deathMarkerHud;
		stored.offhandHud = offhandHud;
		stored.potionHud = potionHud;
		stored.suppliesHud = suppliesHud;
		stored.hudLocked = hudLocked;
		stored.snapHudToGrid = snapHudToGrid;
		stored.autoHudProfileByDimension = autoHudProfileByDimension;
		stored.toggleSprint = toggleSprint;
		stored.noHurtCam = noHurtCam;
		stored.durabilityWarningPercent = durabilityWarningPercent;
		stored.mainhandWarningPercent = mainhandWarningPercent;
		stored.offhandWarningPercent = offhandWarningPercent;
		stored.helmetWarningPercent = helmetWarningPercent;
		stored.chestplateWarningPercent = chestplateWarningPercent;
		stored.leggingsWarningPercent = leggingsWarningPercent;
		stored.bootsWarningPercent = bootsWarningPercent;
		stored.notificationDurationSeconds = notificationDurationSeconds;
		stored.durabilityAlertsHeldItems = durabilityAlertsHeldItems;
		stored.durabilityAlertsArmor = durabilityAlertsArmor;
		stored.notificationPosition = notificationPosition;
		stored.potionFilter = potionFilter;
		stored.trackedItemIds = trackedItemIds;
		stored.gammaBeforeFullbright = gammaBeforeFullbright;
		stored.accentColor = accentColor;
		stored.activeHudProfile = activeHudProfile;
		stored.hudProfiles = hudProfiles;
		stored.mainhandAnchor = mainhandAnchor;
		stored.armorAnchor = armorAnchor;
		stored.statusAnchor = statusAnchor;
		stored.offhandAnchor = offhandAnchor;
		stored.mainhandHudX = mainhandHudX;
		stored.mainhandHudY = mainhandHudY;
		stored.mainhandHudScale = mainhandHudScale;
		stored.mainhandHudOpacity = mainhandHudOpacity;
		stored.armorHudX = armorHudX;
		stored.armorHudY = armorHudY;
		stored.armorHudScale = armorHudScale;
		stored.armorHudOpacity = armorHudOpacity;
		stored.statusHudX = statusHudX;
		stored.statusHudY = statusHudY;
		stored.statusHudScale = statusHudScale;
		stored.statusHudOpacity = statusHudOpacity;
		stored.offhandHudX = offhandHudX;
		stored.offhandHudY = offhandHudY;
		stored.offhandHudScale = offhandHudScale;
		stored.offhandHudOpacity = offhandHudOpacity;
		try {
			Files.createDirectories(CONFIG_PATH.getParent());
			Files.writeString(CONFIG_PATH, GSON.toJson(stored));
		} catch (IOException exception) {
			OpticClientMod.LOGGER.error("Could not save opticclient.json", exception);
		}
	}

	public static boolean exportHudProfiles() {
		ensureBuiltInProfiles();
		capture(hudProfiles.computeIfAbsent(activeHudProfile, ignored -> new HudProfile()));
		try {
			Files.createDirectories(PROFILE_BACKUP_PATH.getParent());
			Files.writeString(PROFILE_BACKUP_PATH, GSON.toJson(hudProfiles));
			return true;
		} catch (IOException exception) {
			OpticClientMod.LOGGER.error("Could not export HUD profiles", exception);
			return false;
		}
	}

	public static boolean importHudProfiles() {
		if (!Files.exists(PROFILE_BACKUP_PATH)) return false;
		Type profileMapType = new TypeToken<LinkedHashMap<String, HudProfile>>() { }.getType();
		try {
			Map<String, HudProfile> imported = GSON.fromJson(Files.readString(PROFILE_BACKUP_PATH), profileMapType);
			if (imported == null || imported.isEmpty()) return false;
			ensureBuiltInProfiles();
			for (Map.Entry<String, HudProfile> entry : imported.entrySet()) {
				if (entry.getKey() != null && entry.getValue() != null) {
					hudProfiles.put(entry.getKey(), entry.getValue());
				}
			}
			if (!hudProfiles.containsKey(activeHudProfile)) activeHudProfile = "Exploration";
			loadHudProfile(activeHudProfile);
			return true;
		} catch (IOException | JsonParseException exception) {
			OpticClientMod.LOGGER.error("Could not import HUD profiles", exception);
			return false;
		}
	}

	public static String getProfileBackupPath() {
		return PROFILE_BACKUP_PATH.toString();
	}

	public enum PotionFilter {
		ALL,
		BENEFICIAL,
		HARMFUL,
		EXPIRING
	}

	public static void saveHudProfile() {
		HudProfile profile = hudProfiles.computeIfAbsent(activeHudProfile, ignored -> new HudProfile());
		capture(profile);
		save();
	}

	public static void loadHudProfile(String name) {
		ensureBuiltInProfiles();
		HudProfile profile = hudProfiles.get(name);
		if (profile == null) {
			return;
		}
		activeHudProfile = name;
		mainhandHud = profile.mainhandHud;
		offhandHud = profile.offhandHud;
		potionHud = profile.potionHud;
		suppliesHud = profile.suppliesHud;
		armorHud = profile.armorHud;
		statusHud = profile.statusHud;
		mainhandAnchor = profile.mainhandAnchor;
		offhandAnchor = profile.offhandAnchor;
		armorAnchor = profile.armorAnchor;
		statusAnchor = profile.statusAnchor;
		mainhandHudX = profile.mainhandHudX;
		mainhandHudY = profile.mainhandHudY;
		mainhandHudScale = profile.mainhandHudScale;
		mainhandHudOpacity = profile.mainhandHudOpacity;
		offhandHudX = profile.offhandHudX;
		offhandHudY = profile.offhandHudY;
		offhandHudScale = profile.offhandHudScale;
		offhandHudOpacity = profile.offhandHudOpacity;
		armorHudX = profile.armorHudX;
		armorHudY = profile.armorHudY;
		armorHudScale = profile.armorHudScale;
		armorHudOpacity = profile.armorHudOpacity;
		statusHudX = profile.statusHudX;
		statusHudY = profile.statusHudY;
		statusHudScale = profile.statusHudScale;
		statusHudOpacity = profile.statusHudOpacity;
		save();
	}

	private static void capture(HudProfile profile) {
		profile.mainhandHud = mainhandHud;
		profile.offhandHud = offhandHud;
				profile.potionHud = potionHud;
				profile.suppliesHud = suppliesHud;
		profile.armorHud = armorHud;
		profile.statusHud = statusHud;
		profile.mainhandAnchor = mainhandAnchor;
		profile.offhandAnchor = offhandAnchor;
		profile.armorAnchor = armorAnchor;
		profile.statusAnchor = statusAnchor;
		profile.mainhandHudX = mainhandHudX;
		profile.mainhandHudY = mainhandHudY;
		profile.mainhandHudScale = mainhandHudScale;
		profile.mainhandHudOpacity = mainhandHudOpacity;
		profile.offhandHudX = offhandHudX;
		profile.offhandHudY = offhandHudY;
		profile.offhandHudScale = offhandHudScale;
		profile.offhandHudOpacity = offhandHudOpacity;
		profile.armorHudX = armorHudX;
		profile.armorHudY = armorHudY;
		profile.armorHudScale = armorHudScale;
		profile.armorHudOpacity = armorHudOpacity;
		profile.statusHudX = statusHudX;
		profile.statusHudY = statusHudY;
		profile.statusHudScale = statusHudScale;
		profile.statusHudOpacity = statusHudOpacity;
	}

	private static void ensureBuiltInProfiles() {
		if (hudProfiles == null) {
			hudProfiles = new LinkedHashMap<>();
		}
		for (String name : HUD_PROFILE_NAMES) {
			hudProfiles.computeIfAbsent(name, ClientConfig::createProfile);
		}
	}

	private static HudProfile createProfile(String name) {
		HudProfile profile = new HudProfile();
		profile.mainhandHud = true;
		profile.armorHud = !"Minimal".equals(name);
		profile.statusHud = true;
		profile.offhandHud = "PvP".equals(name);
				profile.potionHud = true;
				profile.suppliesHud = true;
		profile.mainhandAnchor = HudAnchor.BOTTOM_RIGHT;
		profile.offhandAnchor = HudAnchor.BOTTOM_RIGHT;
		profile.armorAnchor = HudAnchor.BOTTOM_LEFT;
		profile.statusAnchor = HudAnchor.TOP_LEFT;
		profile.mainhandHudX = -1.0f;
		profile.mainhandHudY = -1.0f;
		profile.offhandHudX = -1.0f;
		profile.offhandHudY = -1.0f;
		profile.armorHudX = -1.0f;
		profile.armorHudY = -1.0f;
		profile.statusHudX = -1.0f;
		profile.statusHudY = -1.0f;
		profile.mainhandHudScale = 1.0f;
		profile.offhandHudScale = 1.0f;
		profile.armorHudScale = 1.0f;
		profile.statusHudScale = 1.0f;
		profile.mainhandHudOpacity = 0.72f;
		profile.offhandHudOpacity = 0.72f;
		profile.armorHudOpacity = 0.72f;
		profile.statusHudOpacity = 0.72f;
		return profile;
	}

	public static final class HudProfile {
		boolean mainhandHud = true;
		boolean offhandHud;
		boolean potionHud = true;
		boolean suppliesHud = true;
		boolean armorHud = true;
		boolean statusHud = true;
		boolean deathMarkerHud = true;
		HudAnchor mainhandAnchor = HudAnchor.BOTTOM_RIGHT;
		HudAnchor offhandAnchor = HudAnchor.BOTTOM_RIGHT;
		HudAnchor armorAnchor = HudAnchor.BOTTOM_LEFT;
		HudAnchor statusAnchor = HudAnchor.TOP_LEFT;
		float mainhandHudX = -1.0f;
		float mainhandHudY = -1.0f;
		float mainhandHudScale = 1.0f;
		float mainhandHudOpacity = 0.72f;
		float offhandHudX = -1.0f;
		float offhandHudY = -1.0f;
		float offhandHudScale = 1.0f;
		float offhandHudOpacity = 0.72f;
		float armorHudX = -1.0f;
		float armorHudY = -1.0f;
		float armorHudScale = 1.0f;
		float armorHudOpacity = 0.72f;
		float statusHudX = -1.0f;
		float statusHudY = -1.0f;
		float statusHudScale = 1.0f;
		float statusHudOpacity = 0.72f;
	}

	private static final class StoredConfig {
				boolean potionHud = true;
				boolean suppliesHud = true;
		boolean fullbright;
		boolean mainhandHud = true;
		boolean offhandHud;
		boolean armorHud = true;
		boolean statusHud = true;
		boolean deathMarkerHud = true;
		boolean hudLocked;
		boolean snapHudToGrid = true;
				boolean autoHudProfileByDimension;
		boolean toggleSprint;
		boolean noHurtCam;
		int durabilityWarningPercent = 20;
		int mainhandWarningPercent = 20;
		int offhandWarningPercent = 20;
		int helmetWarningPercent = 20;
		int chestplateWarningPercent = 20;
		int leggingsWarningPercent = 20;
		int bootsWarningPercent = 20;
		int notificationDurationSeconds = 4;
		boolean durabilityAlertsHeldItems = true;
		boolean durabilityAlertsArmor = true;
		HudAnchor notificationPosition = HudAnchor.TOP_RIGHT;
		PotionFilter potionFilter = PotionFilter.ALL;
		String trackedItemIds = "minecraft:totem_of_undying,minecraft:golden_apple";
		double gammaBeforeFullbright = 1.0;
		int accentColor = 0xFF62D6C8;
		String activeHudProfile = "Exploration";
		Map<String, HudProfile> hudProfiles = new LinkedHashMap<>();
		HudAnchor mainhandAnchor = HudAnchor.BOTTOM_RIGHT;
		HudAnchor armorAnchor = HudAnchor.BOTTOM_LEFT;
		HudAnchor statusAnchor = HudAnchor.TOP_LEFT;
		HudAnchor offhandAnchor = HudAnchor.BOTTOM_RIGHT;
		float mainhandHudX = -1.0f;
		float mainhandHudY = -1.0f;
		float mainhandHudScale = 1.0f;
		float mainhandHudOpacity = 0.72f;
		float armorHudX = -1.0f;
		float armorHudY = -1.0f;
		float armorHudScale = 1.0f;
		float armorHudOpacity = 0.72f;
		float statusHudX = -1.0f;
		float statusHudY = -1.0f;
		float statusHudScale = 1.0f;
		float statusHudOpacity = 0.72f;
		float offhandHudX = -1.0f;
		float offhandHudY = -1.0f;
		float offhandHudScale = 1.0f;
		float offhandHudOpacity = 0.72f;
	}
}