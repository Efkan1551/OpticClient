package com.optic.client.hud;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.Util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class DurabilityNotifier {
	private static final Map<String, Alert> ALERTS = new LinkedHashMap<>();
	private static final Set<String> LOW_SLOTS = new HashSet<>();

	private DurabilityNotifier() {
	}

	public static void tick(Minecraft client) {
		if (client.player == null) {
			ALERTS.clear();
			LOW_SLOTS.clear();
			return;
		}

		Map<String, ItemStack> watched = new HashMap<>();
		watched.put("Main hand", client.player.getMainHandItem());
		watched.put("Off hand", client.player.getOffhandItem());
		watched.put("Helmet", client.player.getItemBySlot(EquipmentSlot.HEAD));
		watched.put("Chestplate", client.player.getItemBySlot(EquipmentSlot.CHEST));
		watched.put("Leggings", client.player.getItemBySlot(EquipmentSlot.LEGS));
		watched.put("Boots", client.player.getItemBySlot(EquipmentSlot.FEET));

		long now = Util.getMillis();
		Set<String> currentLow = new HashSet<>();
		for (Map.Entry<String, ItemStack> entry : watched.entrySet()) {
			ItemStack stack = entry.getValue();
			boolean heldItem = entry.getKey().equals("Main hand") || entry.getKey().equals("Off hand");
			if (heldItem ? !ClientConfig.durabilityAlertsHeldItems : !ClientConfig.durabilityAlertsArmor) {
				ALERTS.remove(entry.getKey());
				continue;
			}
			if (stack.isEmpty() || !stack.isDamageableItem()) {
				ALERTS.remove(entry.getKey());
				continue;
			}
			int percent = (stack.getMaxDamage() - stack.getDamageValue()) * 100 / stack.getMaxDamage();
			if (percent < warningPercent(entry.getKey())) {
				currentLow.add(entry.getKey());
				if (!LOW_SLOTS.contains(entry.getKey())) {
					String name = stack.getHoverName().getString();
					long duration = ClientConfig.notificationDurationSeconds * 1000L;
					ALERTS.put(entry.getKey(), new Alert(entry.getKey() + ": " + name + " (" + percent + "%)", now + duration));
				}
			} else {
				ALERTS.remove(entry.getKey());
			}
		}
		LOW_SLOTS.retainAll(currentLow);
		LOW_SLOTS.addAll(currentLow);
		ALERTS.values().removeIf(alert -> alert.expiresAt() <= now);
	}

	private static int warningPercent(String slot) {
		return switch (slot) {
			case "Main hand" -> ClientConfig.mainhandWarningPercent;
			case "Off hand" -> ClientConfig.offhandWarningPercent;
			case "Helmet" -> ClientConfig.helmetWarningPercent;
			case "Chestplate" -> ClientConfig.chestplateWarningPercent;
			case "Leggings" -> ClientConfig.leggingsWarningPercent;
			case "Boots" -> ClientConfig.bootsWarningPercent;
			default -> ClientConfig.durabilityWarningPercent;
		};
	}

	public static void render(GuiGraphicsExtractor graphics, Minecraft client) {
		if (ALERTS.isEmpty() || client.player == null || client.gui.hud.isHidden()) return;
		int row = 0;
		for (Alert alert : ALERTS.values()) {
			int width = Math.min(260, client.font.width(alert.message()) + 24);
			HudAnchor anchor = ClientConfig.notificationPosition;
			int x = anchor.isRight() ? graphics.guiWidth() - width - 8 : 8;
			int y = anchor.isBottom() ? graphics.guiHeight() - 30 - row * 22 : 52 + row * 22;
			graphics.fill(x, y, x + width, y + 18, 0xD9201114);
			graphics.fill(x, y, x + 3, y + 18, 0xFFFF6B6B);
			graphics.text(client.font, alert.message(), x + 9, y + 5, 0xFFFFD6D6, false);
			row++;
		}
	}

	private record Alert(String message, long expiresAt) {
	}
}