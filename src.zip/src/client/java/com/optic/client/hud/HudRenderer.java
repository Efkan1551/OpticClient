package com.optic.client.hud;

import com.optic.client.config.ClientConfig;
import com.optic.client.gui.HudEditorScreen;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class HudRenderer {
	private static final int PANEL = 0xFF0B1115;
	private static final int MUTED = 0xFFB8C4C6;
	private static final int WHITE = 0xFFF2F5F4;
	private static final int WARNING = 0xFFFF6B6B;
	private static final int CAUTION = 0xFFFFC857;
	private static final int STATUS_WIDTH = 204;
	private static final int STATUS_HEIGHT = 280;
	private static final int MAINHAND_WIDTH = 190;
	private static final int MAINHAND_HEIGHT = 36;
	private static final int ARMOR_WIDTH = 66;
	private static final int ARMOR_HEIGHT = 96;
	private static final int MAX_TRACKED_ITEMS = 5;

	public enum Element {
		MAINHAND,
		OFFHAND,
		ARMOR,
		STATUS;

		public Element next() {
			return values()[(ordinal() + 1) % values().length];
		}
	}

	public record Bounds(int x, int y, int width, int height) {
		public boolean contains(double mouseX, double mouseY) {
			return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
		}
	}

	private HudRenderer() {
	}

	public static void register() {
		HudElementRegistry.attachElementBefore(
				VanillaHudElements.CHAT,
				Identifier.fromNamespaceAndPath("opticclient", "utility_hud"),
				(graphics, deltaTracker) -> render(graphics)
		);
	}

	private static void render(GuiGraphicsExtractor graphics) {
		Minecraft client = Minecraft.getInstance();
		boolean editing = client.gui.screen() instanceof HudEditorScreen;
		if (client.player == null || (client.gui.hud.isHidden() && !editing)) {
			return;
		}
		if (ClientConfig.statusHud || ClientConfig.deathMarkerHud || ClientConfig.potionHud || ClientConfig.suppliesHud || editing) {
			renderElement(graphics, client, Element.STATUS, editing);
		}
		if (ClientConfig.armorHud || editing) renderElement(graphics, client, Element.ARMOR, editing);
		if (ClientConfig.mainhandHud || editing) renderElement(graphics, client, Element.MAINHAND, editing);
		if (ClientConfig.offhandHud || editing) renderElement(graphics, client, Element.OFFHAND, editing);
		DurabilityNotifier.render(graphics, client);
	}

	private static void renderElement(GuiGraphicsExtractor graphics, Minecraft client, Element element, boolean editing) {
		Bounds bounds = getBounds(element, graphics.guiWidth(), graphics.guiHeight());
		float scale = getScale(element);
		graphics.pose().pushMatrix();
		graphics.pose().translate(bounds.x(), bounds.y());
		graphics.pose().scale(scale, scale);
		switch (element) {
			case STATUS -> renderStatus(graphics, client, getOpacity(element));
			case ARMOR -> renderArmor(graphics, client, getOpacity(element), editing);
			case MAINHAND -> renderHeldItem(graphics, client, getOpacity(element), editing, false);
			case OFFHAND -> renderHeldItem(graphics, client, getOpacity(element), editing, true);
		}
		graphics.pose().popMatrix();
		if (editing && HudEditorScreen.isElementSelected(element)) {
			graphics.outline(bounds.x(), bounds.y(), bounds.width(), bounds.height(), ClientConfig.accentColor);
		}
	}

	public static Bounds getBounds(Element element, int screenWidth, int screenHeight) {
		float scale = getScale(element);
		int width = Math.round(baseWidth(element) * scale);
		int height = Math.round(baseHeight(element) * scale);
		HudAnchor anchor = anchor(element);
		int defaultX = anchor.isRight() ? screenWidth - width - 8 : 8;
		int defaultY = anchor.isBottom() ? screenHeight - height - 8 : 8;
		if (element == Element.OFFHAND && anchor.isBottom()) defaultY -= MAINHAND_HEIGHT + 8;
		float normalizedX = positionX(element);
		float normalizedY = positionY(element);
		int x = normalizedX < 0.0f ? defaultX : Math.round(normalizedX * Math.max(0, screenWidth - width));
		int y = normalizedY < 0.0f ? defaultY : Math.round(normalizedY * Math.max(0, screenHeight - height));
		return new Bounds(clamp(x, 0, Math.max(0, screenWidth - width)),
				clamp(y, 0, Math.max(0, screenHeight - height)), width, height);
	}

	public static void setPosition(Element element, int x, int y, int screenWidth, int screenHeight) {
		Bounds bounds = getBounds(element, screenWidth, screenHeight);
		if (ClientConfig.snapHudToGrid) {
			x = Math.round(x / 8.0f) * 8;
			y = Math.round(y / 8.0f) * 8;
		}
		float normalizedX = clamp(x, 0, Math.max(0, screenWidth - bounds.width()))
				/ (float) Math.max(1, screenWidth - bounds.width());
		float normalizedY = clamp(y, 0, Math.max(0, screenHeight - bounds.height()))
				/ (float) Math.max(1, screenHeight - bounds.height());
		switch (element) {
			case MAINHAND -> {
				ClientConfig.mainhandHudX = normalizedX;
				ClientConfig.mainhandHudY = normalizedY;
			}
			case OFFHAND -> {
				ClientConfig.offhandHudX = normalizedX;
				ClientConfig.offhandHudY = normalizedY;
			}
			case ARMOR -> {
				ClientConfig.armorHudX = normalizedX;
				ClientConfig.armorHudY = normalizedY;
			}
			case STATUS -> {
				ClientConfig.statusHudX = normalizedX;
				ClientConfig.statusHudY = normalizedY;
			}
		}
	}

	public static void moveBy(Element element, int deltaX, int deltaY, int screenWidth, int screenHeight) {
		Bounds bounds = getBounds(element, screenWidth, screenHeight);
		setPosition(element, bounds.x() + deltaX, bounds.y() + deltaY, screenWidth, screenHeight);
	}

	public static float getScale(Element element) {
		return switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudScale;
			case OFFHAND -> ClientConfig.offhandHudScale;
			case ARMOR -> ClientConfig.armorHudScale;
			case STATUS -> ClientConfig.statusHudScale;
		};
	}

	public static float getOpacity(Element element) {
		return switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudOpacity;
			case OFFHAND -> ClientConfig.offhandHudOpacity;
			case ARMOR -> ClientConfig.armorHudOpacity;
			case STATUS -> ClientConfig.statusHudOpacity;
		};
	}

	public static void adjustScale(Element element, float delta) {
		switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudScale = clamp(ClientConfig.mainhandHudScale + delta, 0.6f, 2.0f);
			case OFFHAND -> ClientConfig.offhandHudScale = clamp(ClientConfig.offhandHudScale + delta, 0.6f, 2.0f);
			case ARMOR -> ClientConfig.armorHudScale = clamp(ClientConfig.armorHudScale + delta, 0.6f, 2.0f);
			case STATUS -> ClientConfig.statusHudScale = clamp(ClientConfig.statusHudScale + delta, 0.6f, 2.0f);
		}
	}

	public static void adjustOpacity(Element element, float delta) {
		switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudOpacity = clamp(ClientConfig.mainhandHudOpacity + delta, 0.15f, 1.0f);
			case OFFHAND -> ClientConfig.offhandHudOpacity = clamp(ClientConfig.offhandHudOpacity + delta, 0.15f, 1.0f);
			case ARMOR -> ClientConfig.armorHudOpacity = clamp(ClientConfig.armorHudOpacity + delta, 0.15f, 1.0f);
			case STATUS -> ClientConfig.statusHudOpacity = clamp(ClientConfig.statusHudOpacity + delta, 0.15f, 1.0f);
		}
	}

	public static void resetLayouts() {
		ClientConfig.mainhandAnchor = HudAnchor.BOTTOM_RIGHT;
		ClientConfig.offhandAnchor = HudAnchor.BOTTOM_RIGHT;
		ClientConfig.armorAnchor = HudAnchor.BOTTOM_LEFT;
		ClientConfig.statusAnchor = HudAnchor.TOP_LEFT;
		ClientConfig.mainhandHudX = -1.0f;
		ClientConfig.mainhandHudY = -1.0f;
		ClientConfig.offhandHudX = -1.0f;
		ClientConfig.offhandHudY = -1.0f;
		ClientConfig.armorHudX = -1.0f;
		ClientConfig.armorHudY = -1.0f;
		ClientConfig.statusHudX = -1.0f;
		ClientConfig.statusHudY = -1.0f;
		ClientConfig.mainhandHudScale = 1.0f;
		ClientConfig.offhandHudScale = 1.0f;
		ClientConfig.armorHudScale = 1.0f;
		ClientConfig.statusHudScale = 1.0f;
		ClientConfig.mainhandHudOpacity = 0.72f;
		ClientConfig.offhandHudOpacity = 0.72f;
		ClientConfig.armorHudOpacity = 0.72f;
		ClientConfig.statusHudOpacity = 0.72f;
	}

	private static void renderStatus(GuiGraphicsExtractor graphics, Minecraft client, float opacity) {
		List<MobEffectInstance> effects = new ArrayList<>();
		if (ClientConfig.potionHud) {
			for (MobEffectInstance effect : client.player.getActiveEffects()) {
				if (effect.showIcon() && matchesPotionFilter(effect)) effects.add(effect);
			}
		}
		int visibleEffects = Math.min(5, effects.size());
		List<TrackedItem> trackedItems = ClientConfig.suppliesHud ? getTrackedItems(client) : List.of();
		int height = 12;
		if (ClientConfig.statusHud) height += 6 * 12 + 4;
		String deathMarker = ClientConfig.deathMarkerHud ? deathMarkerText(client).orElse(null) : null;
		if (deathMarker != null) height += 14;
		if (ClientConfig.potionHud) {
			height += visibleEffects == 0 ? 14 : visibleEffects * 18 + 4;
			if (effects.size() > visibleEffects) height += 14;
		}
		if (ClientConfig.suppliesHud) height += Math.max(14, trackedItems.size() * 14) + 4;
		panel(graphics, 0, 0, STATUS_WIDTH, Math.max(30, height), opacity);

		int lineY = 6;
		if (ClientConfig.statusHud) {
			int ping = -1;
			if (client.getConnection() != null && client.getConnection().getPlayerInfo(client.player.getUUID()) != null) {
				ping = client.getConnection().getPlayerInfo(client.player.getUUID()).getLatency();
			}
			String biome = client.level.getBiome(client.player.blockPosition()).unwrapKey()
					.map(key -> humanize(key.identifier().getPath())).orElse("unknown");
			String direction = client.player.getDirection().getName().toUpperCase(Locale.ROOT);
			List<String> lines = new ArrayList<>(List.of(
					"FPS  " + client.getFps(),
					"PING " + (ping < 0 ? "--" : ping + " ms"),
					String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f", client.player.getX(), client.player.getY(), client.player.getZ()),
					"BIOME  " + trim(client, biome, 180),
					"FACING  " + direction,
					"TIME  " + worldTime(client)
			));
			for (int index = 0; index < lines.size(); index++) {
				int color = index == 0 ? ClientConfig.accentColor : MUTED;
				graphics.text(client.font, lines.get(index), 8, lineY + index * 12, withOpacity(color, opacity), false);
			}
			lineY += lines.size() * 12 + 4;
		}
		if (deathMarker != null) {
			graphics.text(client.font, deathMarker, 8, lineY, withOpacity(ClientConfig.accentColor, opacity), false);
			lineY += 14;
		}

		if (ClientConfig.potionHud) {
			if (effects.isEmpty()) {
				graphics.text(client.font, "EFFECTS  none", 8, lineY, withOpacity(MUTED, opacity), false);
				lineY += 14;
			}
			for (int index = 0; index < visibleEffects; index++) {
				MobEffectInstance effect = effects.get(index);
				String effectName = effect.getEffect().value().getDisplayName().getString();
				String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
				String duration = effect.isInfiniteDuration() ? "INF" : formatDuration(effect.getDuration());
				int color = !effect.isInfiniteDuration() && effect.getDuration() <= 200 ? WARNING : WHITE;
				Identifier effectId = effect.getEffect().unwrapKey()
						.map(key -> Identifier.fromNamespaceAndPath(key.identifier().getNamespace(),
								"textures/mob_effect/" + key.identifier().getPath() + ".png"))
						.orElse(Identifier.fromNamespaceAndPath("minecraft", "textures/mob_effect/unknown.png"));
				graphics.blit(RenderPipelines.GUI_TEXTURED, effectId, 8, lineY, 0, 0, 12, 12, 18, 18);
				String label = trim(client, effectName + level + "  " + duration, 176);
				graphics.text(client.font, label, 24, lineY + 2, withOpacity(color, opacity), false);
				lineY += 18;
			}
			if (effects.size() > visibleEffects) {
				graphics.text(client.font, "+" + (effects.size() - visibleEffects) + " more effects",
						8, lineY, withOpacity(MUTED, opacity), false);
				lineY += 14;
			}
		}

		if (ClientConfig.suppliesHud) {
			if (trackedItems.isEmpty()) {
				graphics.text(client.font, "ITEMS  none configured", 8, lineY, withOpacity(MUTED, opacity), false);
			} else {
				for (TrackedItem tracked : trackedItems) {
					graphics.item(tracked.item().getDefaultInstance(), 8, lineY - 2);
					graphics.text(client.font, trim(client, tracked.name() + "  x" + tracked.count(), 164),
							28, lineY + 2, withOpacity(ClientConfig.accentColor, opacity), false);
					lineY += 14;
				}
			}
		}
	}

	private static List<TrackedItem> getTrackedItems(Minecraft client) {
		List<TrackedItem> trackedItems = new ArrayList<>();
		for (String entry : ClientConfig.trackedItemIds.split(",")) {
			if (trackedItems.size() >= MAX_TRACKED_ITEMS) break;
			Identifier id = Identifier.tryParse(entry.trim());
			if (id == null) continue;
			Item item = BuiltInRegistries.ITEM.getOptional(id).orElse(null);
			if (item == null) continue;
			trackedItems.add(new TrackedItem(humanize(id.getPath()), countItem(client, item), item));
		}
		return trackedItems;
	}

	private static boolean matchesPotionFilter(MobEffectInstance effect) {
		return switch (ClientConfig.potionFilter) {
			case ALL -> true;
			case BENEFICIAL -> effect.getEffect().value().getCategory() == MobEffectCategory.BENEFICIAL;
			case HARMFUL -> effect.getEffect().value().getCategory() == MobEffectCategory.HARMFUL;
			case EXPIRING -> !effect.isInfiniteDuration() && effect.getDuration() <= 1200;
		};
	}

	private static int countItem(Minecraft client, Item item) {
		int count = 0;
		for (int slot = 0; slot < client.player.getInventory().getContainerSize(); slot++) {
			ItemStack stack = client.player.getInventory().getItem(slot);
			if (stack.is(item)) count += stack.getCount();
		}
		return count;
	}

	private record TrackedItem(String name, int count, Item item) {
	}

	private static java.util.Optional<String> deathMarkerText(Minecraft client) {
		return client.player.getLastDeathLocation().map(death -> {
			String dimension = humanize(death.dimension().identifier().getPath());
			var position = death.pos();
			if (!death.dimension().equals(client.level.dimension())) {
				return "DEATH  " + dimension + "  " + position.getX() + " " + position.getY() + " " + position.getZ();
			}
			double dx = client.player.getX() - position.getX();
			double dy = client.player.getY() - position.getY();
			double dz = client.player.getZ() - position.getZ();
			int distance = (int) Math.round(Math.sqrt(dx * dx + dy * dy + dz * dz));
			return "DEATH  " + position.getX() + " " + position.getY() + " " + position.getZ() + "  " + distance + "m";
		});
	}

	private static String formatDuration(int ticks) {
		int seconds = Math.max(0, ticks / 20);
		return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
	}

	private static void renderHeldItem(GuiGraphicsExtractor graphics, Minecraft client, float opacity, boolean editing, boolean offhand) {
		ItemStack stack = offhand ? client.player.getOffhandItem() : client.player.getMainHandItem();
		if (stack.isEmpty() && !editing) {
			return;
		}
		panel(graphics, 0, 0, MAINHAND_WIDTH, MAINHAND_HEIGHT, opacity);
		if (!stack.isEmpty()) graphics.item(stack, 8, 9);
		String handName = offhand ? "Off hand" : "Main hand";
		String name = stack.isEmpty() ? handName : stack.getHoverName().getString();
		int durability = stack.isDamageableItem() ? stack.getMaxDamage() - stack.getDamageValue() : -1;
		int percent = durability < 0 ? -1 : durability * 100 / stack.getMaxDamage();
		int warningPercent = offhand ? ClientConfig.offhandWarningPercent : ClientConfig.mainhandWarningPercent;
		String detail = (stack.getCount() > 1 ? "x" + stack.getCount() : "")
				+ (percent >= 0 ? (stack.getCount() > 1 ? "  " : "") + percent + "% durability"
						+ (percent < warningPercent ? "  LOW" : "") : "");
		graphics.text(client.font, trim(client, name, 150), 34, 7, withOpacity(WHITE, opacity), false);
		if (!detail.isBlank()) {
			int cautionAt = Math.min(100, warningPercent + 20);
			int color = percent >= 0 && percent < warningPercent ? WARNING
					: percent >= 0 && percent <= cautionAt ? CAUTION : MUTED;
			graphics.text(client.font, detail, 34, 20, withOpacity(color, opacity), false);
		}
	}

	private static void renderArmor(GuiGraphicsExtractor graphics, Minecraft client, float opacity, boolean editing) {
		int slotSize = 22;
		panel(graphics, 0, 0, ARMOR_WIDTH, ARMOR_HEIGHT, opacity);
		EquipmentSlot[] slots = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
		for (int index = 0; index < slots.length; index++) {
			ItemStack stack = client.player.getItemBySlot(slots[index]);
			int itemY = 4 + index * slotSize;
			if (!stack.isEmpty()) graphics.item(stack, 4, itemY);
			else if (editing) graphics.text(client.font, "--", 8, itemY + 5, withOpacity(MUTED, opacity), false);
			if (!stack.isEmpty() && stack.isDamageableItem()) {
				int percent = (stack.getMaxDamage() - stack.getDamageValue()) * 100 / stack.getMaxDamage();
				int warningPercent = armorWarningPercent(slots[index]);
				int cautionAt = Math.min(100, warningPercent + 20);
				int color = percent < warningPercent ? WARNING
						: percent <= cautionAt ? CAUTION : ClientConfig.accentColor;
				graphics.text(client.font, percent + "%" + (percent < warningPercent ? "!" : ""),
						26, itemY + 5, withOpacity(color, opacity), false);
			}
		}
	}

	private static int armorWarningPercent(EquipmentSlot slot) {
		return switch (slot) {
			case HEAD -> ClientConfig.helmetWarningPercent;
			case CHEST -> ClientConfig.chestplateWarningPercent;
			case LEGS -> ClientConfig.leggingsWarningPercent;
			case FEET -> ClientConfig.bootsWarningPercent;
			default -> ClientConfig.durabilityWarningPercent;
		};
	}

	private static void panel(GuiGraphicsExtractor graphics, int x, int y, int width, int height, float opacity) {
		graphics.fill(x, y, x + width, y + height, withOpacity(PANEL, opacity));
		graphics.fill(x, y, x + 2, y + height, withOpacity(ClientConfig.accentColor, opacity));
	}

	private static String worldTime(Minecraft client) {
		return client.level.dimensionTypeRegistration().value().defaultClock()
				.map(clock -> {
					long ticks = client.level.clockManager().getInstance(clock).totalTicks();
					int minutes = (int) (Math.floorMod(ticks, 24000L) * 1440L / 24000L + 360) % 1440;
					return String.format(Locale.ROOT, "%02d:%02d", minutes / 60, minutes % 60);
				}).orElse("--:--");
	}

	private static HudAnchor anchor(Element element) {
		return switch (element) {
			case MAINHAND -> ClientConfig.mainhandAnchor;
			case OFFHAND -> ClientConfig.offhandAnchor;
			case ARMOR -> ClientConfig.armorAnchor;
			case STATUS -> ClientConfig.statusAnchor;
		};
	}

	private static float positionX(Element element) {
		return switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudX;
			case OFFHAND -> ClientConfig.offhandHudX;
			case ARMOR -> ClientConfig.armorHudX;
			case STATUS -> ClientConfig.statusHudX;
		};
	}

	private static float positionY(Element element) {
		return switch (element) {
			case MAINHAND -> ClientConfig.mainhandHudY;
			case OFFHAND -> ClientConfig.offhandHudY;
			case ARMOR -> ClientConfig.armorHudY;
			case STATUS -> ClientConfig.statusHudY;
		};
	}

	private static int baseWidth(Element element) {
		return switch (element) {
			case MAINHAND -> MAINHAND_WIDTH;
			case OFFHAND -> MAINHAND_WIDTH;
			case ARMOR -> ARMOR_WIDTH;
			case STATUS -> STATUS_WIDTH;
		};
	}

	private static int baseHeight(Element element) {
		return switch (element) {
			case MAINHAND -> MAINHAND_HEIGHT;
			case OFFHAND -> MAINHAND_HEIGHT;
			case ARMOR -> ARMOR_HEIGHT;
			case STATUS -> STATUS_HEIGHT;
		};
	}

	private static int withOpacity(int color, float opacity) {
		int alpha = Math.round(((color >>> 24) & 0xFF) * opacity);
		return (alpha << 24) | (color & 0x00FFFFFF);
	}

	private static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}

	private static float clamp(float value, float min, float max) {
		return Math.max(min, Math.min(max, value));
	}

	private static String humanize(String value) {
		String[] words = value.replace('_', ' ').split(" ");
		StringBuilder result = new StringBuilder();
		for (String word : words) {
			if (!word.isEmpty()) {
				if (!result.isEmpty()) result.append(' ');
				result.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
			}
		}
		return result.toString();
	}

	private static String trim(Minecraft client, String text, int maxWidth) {
		if (client.font.width(text) <= maxWidth) {
			return text;
		}
		while (!text.isEmpty() && client.font.width(text + "...") > maxWidth) {
			text = text.substring(0, text.length() - 1);
		}
		return text + "...";
	}
}