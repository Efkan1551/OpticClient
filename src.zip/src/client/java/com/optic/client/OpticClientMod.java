package com.optic.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.optic.client.config.ClientConfig;
import com.optic.client.gui.ClickGuiScreen;
import com.optic.client.hud.DurabilityNotifier;
import com.optic.client.hud.HudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class OpticClientMod implements ClientModInitializer {
	public static final String MOD_ID = "opticclient";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	private static final KeyMapping.Category KEY_CATEGORY = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(MOD_ID, "general")
	);
	private static KeyMapping openGuiKey;
	private static KeyMapping minimalProfileKey;
	private static KeyMapping pvpProfileKey;
	private static KeyMapping explorationProfileKey;
	private static KeyMapping mainhandHudKey;
	private static KeyMapping offhandHudKey;
	private static KeyMapping armorHudKey;
	private static KeyMapping statusHudKey;
	private static KeyMapping potionHudKey;
	private static KeyMapping suppliesHudKey;
	private static KeyMapping deathMarkerHudKey;
	private static double gammaBeforeFullbright = 1.0;
	private static String lastProfileDimension;

	@Override
	public void onInitializeClient() {
		ClientConfig.load();
		gammaBeforeFullbright = ClientConfig.gammaBeforeFullbright;

		openGuiKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.opticclient.open_gui",
				InputConstants.Type.KEYBOARD,
				InputConstants.KEY_RSHIFT,
				KEY_CATEGORY
		));
		minimalProfileKey = registerKey("minimal_profile", InputConstants.KEY_F6);
		pvpProfileKey = registerKey("pvp_profile", InputConstants.KEY_F7);
		explorationProfileKey = registerKey("exploration_profile", InputConstants.KEY_F8);
		mainhandHudKey = registerKey("toggle_mainhand_hud", InputConstants.KEY_F9);
		offhandHudKey = registerKey("toggle_offhand_hud", InputConstants.KEY_F10);
		armorHudKey = registerKey("toggle_armor_hud", InputConstants.KEY_F11);
		statusHudKey = registerKey("toggle_status_hud", InputConstants.KEY_F12);
		potionHudKey = registerKey("toggle_potion_hud", InputConstants.UNKNOWN.getValue());
		suppliesHudKey = registerKey("toggle_supplies_hud", InputConstants.UNKNOWN.getValue());
		deathMarkerHudKey = registerKey("toggle_death_marker_hud", InputConstants.UNKNOWN.getValue());

		HudRenderer.register();
		ClientLifecycleEvents.CLIENT_STARTED.register(OpticClientMod::onClientStarted);
		ClientTickEvents.END_CLIENT_TICK.register(OpticClientMod::onEndTick);
		ClientLifecycleEvents.CLIENT_STOPPING.register(ignored -> ClientConfig.save());
	}

	private static void onClientStarted(Minecraft client) {
		if (ClientConfig.fullbright) {
			client.options.gamma().set(1.0);
		}
	}

	private static void onEndTick(Minecraft client) {
		DurabilityNotifier.tick(client);
		updateDimensionProfile(client);
		handleHotkeys();

		while (openGuiKey.consumeClick()) {
			if (client.gui.screen() == null || client.gui.screen() instanceof ClickGuiScreen) {
				client.gui.setScreen(client.gui.screen() instanceof ClickGuiScreen ? null : new ClickGuiScreen());
			}
		}

		if (ClientConfig.fullbright && client.options.gamma().get() != 1.0) {
			client.options.gamma().set(1.0);
		}

		if (ClientConfig.toggleSprint && client.player != null
				&& client.player.input.hasForwardImpulse()
				&& !client.player.isShiftKeyDown()) {
			client.player.setSprinting(true);
		}
	}

	private static KeyMapping registerKey(String name, int keyCode) {
		return KeyMappingHelper.registerKeyMapping(new KeyMapping(
				"key.opticclient." + name,
				InputConstants.Type.KEYBOARD,
				keyCode,
				KEY_CATEGORY
		));
	}

	private static void handleHotkeys() {
		if (minimalProfileKey.consumeClick()) ClientConfig.loadHudProfile("Minimal");
		if (pvpProfileKey.consumeClick()) ClientConfig.loadHudProfile("PvP");
		if (explorationProfileKey.consumeClick()) ClientConfig.loadHudProfile("Exploration");
		toggle(mainhandHudKey, () -> ClientConfig.mainhandHud = !ClientConfig.mainhandHud);
		toggle(offhandHudKey, () -> ClientConfig.offhandHud = !ClientConfig.offhandHud);
		toggle(armorHudKey, () -> ClientConfig.armorHud = !ClientConfig.armorHud);
		toggle(statusHudKey, () -> ClientConfig.statusHud = !ClientConfig.statusHud);
		toggle(potionHudKey, () -> ClientConfig.potionHud = !ClientConfig.potionHud);
		toggle(suppliesHudKey, () -> ClientConfig.suppliesHud = !ClientConfig.suppliesHud);
		toggle(deathMarkerHudKey, () -> ClientConfig.deathMarkerHud = !ClientConfig.deathMarkerHud);
	}

	private static void toggle(KeyMapping key, Runnable toggle) {
		while (key.consumeClick()) {
			toggle.run();
			ClientConfig.save();
		}
	}

	private static void updateDimensionProfile(Minecraft client) {
		if (!ClientConfig.autoHudProfileByDimension || client.level == null) {
			lastProfileDimension = null;
			return;
		}
		String dimension = client.level.dimension().identifier().getPath();
		if (dimension.equals(lastProfileDimension)) {
			return;
		}
		lastProfileDimension = dimension;
		String profile = switch (dimension) {
			case "overworld" -> "Exploration";
			case "the_nether" -> "PvP";
			case "the_end" -> "Minimal";
			default -> null;
		};
		if (profile != null && !profile.equals(ClientConfig.activeHudProfile)) {
			ClientConfig.loadHudProfile(profile);
		}
	}

	public static void setFullbright(boolean enabled) {
		Minecraft client = Minecraft.getInstance();
		if (enabled && !ClientConfig.fullbright) {
			gammaBeforeFullbright = client.options.gamma().get();
			ClientConfig.gammaBeforeFullbright = gammaBeforeFullbright;
			client.options.gamma().set(1.0);
		} else if (!enabled && ClientConfig.fullbright) {
			client.options.gamma().set(gammaBeforeFullbright);
		}
		ClientConfig.fullbright = enabled;
	}
}