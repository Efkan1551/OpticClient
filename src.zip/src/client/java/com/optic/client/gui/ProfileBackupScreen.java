package com.optic.client.gui;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ProfileBackupScreen extends Screen {
	private final Screen parent;
	private String status = "";
	private int panelX;
	private int panelY;
	private int panelWidth;

	public ProfileBackupScreen(Screen parent) {
		super(Component.literal("HUD Profile Backup"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		clearWidgets();
		panelWidth = Math.min(430, width - 24);
		panelX = (width - panelWidth) / 2;
		panelY = Math.max(16, (height - 240) / 2);
		int half = (panelWidth - 44) / 2;
		addRenderableWidget(Button.builder(Component.literal("Export profiles"), button -> {
			status = ClientConfig.exportHudProfiles() ? "Exported" : "Export failed";
		}).bounds(panelX + 20, panelY + 76, half, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Import profiles"), button -> {
			status = ClientConfig.importHudProfiles() ? "Imported" : "Backup not found or invalid";
			ClientConfig.save();
		}).bounds(panelX + 24 + half, panelY + 76, half, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Back"), button -> onClose())
				.bounds(panelX + panelWidth / 2 - 55, panelY + 126, 110, 22).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, width, height, 0x99050A0D);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 170, 0xF20B1115);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, ClientConfig.accentColor);
		graphics.outline(panelX, panelY, panelWidth, 170, 0xFF3B494B);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "HUD PROFILES", panelX + 20, panelY + 22, 0xFFF2F5F4, false);
		graphics.text(font, ClientConfig.getProfileBackupPath(), panelX + 20, panelY + 48, 0xFFB8C4C6, false);
		if (!status.isEmpty()) graphics.text(font, status, panelX + 20, panelY + 112, ClientConfig.accentColor, false);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}