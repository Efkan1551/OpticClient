package com.optic.client.gui;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class ItemTrackerScreen extends Screen {
	private final Screen parent;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private EditBox itemIds;
	private String status = "";

	public ItemTrackerScreen(Screen parent) {
		super(Component.literal("Tracked Items"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		clearWidgets();
		panelWidth = Math.min(520, width - 24);
		panelX = (width - panelWidth) / 2;
		panelY = Math.max(20, (height - 190) / 2);
		itemIds = new EditBox(font, panelX + 20, panelY + 72, panelWidth - 40, 22, Component.literal("Item IDs"));
		itemIds.setValue(ClientConfig.trackedItemIds);
		itemIds.setHint(Component.literal("minecraft:totem_of_undying,minecraft:golden_apple"));
		addRenderableWidget(itemIds);
		addRenderableWidget(Button.builder(Component.literal("Save"), button -> {
			ClientConfig.trackedItemIds = itemIds.getValue();
			ClientConfig.save();
			status = "Saved";
		}).bounds(panelX + panelWidth / 2 - 108, panelY + 124, 100, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Back"), button -> onClose())
				.bounds(panelX + panelWidth / 2 + 8, panelY + 124, 100, 22).build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, width, height, 0x99050A0D);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 166, 0xF20B1115);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, ClientConfig.accentColor);
		graphics.outline(panelX, panelY, panelWidth, 166, 0xFF3B494B);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "TRACKED ITEM IDS", panelX + 20, panelY + 22, 0xFFF2F5F4, false);
		graphics.text(font, "Separate namespaced IDs with commas (max 5 shown).", panelX + 20,
				panelY + 48, 0xFFB8C4C6, false);
		if (!status.isEmpty()) graphics.text(font, status, panelX + panelWidth - 72, panelY + 130, ClientConfig.accentColor, false);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}