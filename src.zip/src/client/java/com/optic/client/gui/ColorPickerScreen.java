package com.optic.client.gui;

import com.optic.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;

public final class ColorPickerScreen extends Screen {
	private final Screen parent;
	private final int[] channels = new int[3];
	private int panelX;
	private int panelY;
	private int panelWidth;
	private int sliderX;
	private int sliderWidth;

	public ColorPickerScreen(Screen parent) {
		super(Component.literal("Accent Color"));
		this.parent = parent;
		channels[0] = (ClientConfig.accentColor >> 16) & 0xFF;
		channels[1] = (ClientConfig.accentColor >> 8) & 0xFF;
		channels[2] = ClientConfig.accentColor & 0xFF;
	}

	@Override
	protected void init() {
		clearWidgets();
		panelWidth = Math.min(360, width - 24);
		panelX = (width - panelWidth) / 2;
		panelY = Math.max(16, (height - 300) / 2);
		sliderX = panelX + 28;
		sliderWidth = panelWidth - 56;
		String[] labels = {"RED", "GREEN", "BLUE"};
		for (int channel = 0; channel < channels.length; channel++) {
			int sliderY = panelY + 94 + channel * 52;
			addRenderableWidget(new ChannelSlider(sliderX, sliderY, sliderWidth, labels[channel], channel,
					channels[channel] / 255.0));
		}
		addRenderableWidget(Button.builder(Component.literal("Back"), button -> onClose())
				.bounds(panelX + panelWidth / 2 - 55, panelY + 260, 110, 22).build());
	}

	private void updateColor() {
		ClientConfig.accentColor = 0xFF000000 | channels[0] << 16 | channels[1] << 8 | channels[2];
	}

	private final class ChannelSlider extends AbstractSliderButton {
		private final int channel;
		private final String label;

		private ChannelSlider(int x, int y, int sliderWidth, String label, int channel, double value) {
			super(x, y, sliderWidth, 20, Component.empty(), value);
			this.label = label;
			this.channel = channel;
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			setMessage(Component.literal(label + "  " + channels[channel]));
		}

		@Override
		protected void applyValue() {
			channels[channel] = (int) Math.round(value * 255.0);
			updateColor();
		}
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, width, height, 0x99050A0D);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 292, 0xF20B1115);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, ClientConfig.accentColor);
		graphics.outline(panelX, panelY, panelWidth, 292, 0xFF3B494B);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "CUSTOM ACCENT", panelX + 20, panelY + 18, 0xFFF2F5F4, false);
		graphics.text(font, "RGB  " + channels[0] + "  /  " + channels[1] + "  /  " + channels[2],
				panelX + 20, panelY + 42, 0xFFB8C4C6, false);
		graphics.text(font, "#" + String.format(Locale.ROOT, "%02X%02X%02X", channels[0], channels[1], channels[2]),
				panelX + 20, panelY + 59, ClientConfig.accentColor, false);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}