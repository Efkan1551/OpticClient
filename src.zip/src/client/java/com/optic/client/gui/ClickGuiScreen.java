package com.optic.client.gui;

import com.optic.client.OpticClientMod;
import com.optic.client.config.ClientConfig;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;

public final class ClickGuiScreen extends Screen {
	private static final String[] CATEGORIES = {"All", "HUD", "Visual", "QoL", "Profiles"};
	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;
	private final List<FeatureWidget> featureWidgets = new ArrayList<>();
	private final List<Button> categoryButtons = new ArrayList<>();
	private String selectedCategory = "All";
	private String searchQuery = "";
	private EditBox searchBox;
	private Button profileButton;
	private Button saveProfileButton;
	private Button durabilityButton;
	private Button potionFilterButton;

	private record FeatureWidget(String label, String category, BooleanSupplier enabled, Runnable toggle, Button button) {
	}

	public ClickGuiScreen() {
		super(Component.literal("OpticClientMod"));
	}

	@Override
	protected void init() {
		clearWidgets();
		featureWidgets.clear();
		categoryButtons.clear();
		panelWidth = Math.min(520, width - 24);
		panelHeight = Math.min(480, height - 24);
		panelX = (width - panelWidth) / 2;
		panelY = Math.max(12, (height - panelHeight) / 2);

		int gap = 6;
		int left = panelX + 20;
		int contentWidth = panelWidth - 40;
		searchBox = new EditBox(font, left, panelY + 51, contentWidth, 20, Component.literal("Search features"));
		searchBox.setHint(Component.literal("Search features..."));
		searchBox.setValue(searchQuery);
		searchBox.setResponder(value -> {
			searchQuery = value.toLowerCase(Locale.ROOT);
			refreshFeatureWidgets();
		});
		addRenderableWidget(searchBox);

		int categoryWidth = (contentWidth - gap * 3) / CATEGORIES.length;
		for (int index = 0; index < CATEGORIES.length; index++) {
			String category = CATEGORIES[index];
			Button button = addRenderableWidget(Button.builder(categoryMessage(category), ignored -> {
				selectedCategory = category;
				refreshCategoryButtons();
				refreshFeatureWidgets();
			}).bounds(left + index * (categoryWidth + gap), panelY + 77, categoryWidth, 20).build());
			categoryButtons.add(button);
		}

		int columnWidth = (contentWidth - gap) / 2;
		int featureY = panelY + 112;
		addToggle("Fullbright", "Visual", () -> ClientConfig.fullbright,
				() -> OpticClientMod.setFullbright(!ClientConfig.fullbright), left, featureY, columnWidth);
		addToggle("Mainhand HUD", "HUD", () -> ClientConfig.mainhandHud,
				() -> ClientConfig.mainhandHud = !ClientConfig.mainhandHud,
				left + columnWidth + gap, featureY, columnWidth);
		addToggle("Offhand HUD", "HUD", () -> ClientConfig.offhandHud,
				() -> ClientConfig.offhandHud = !ClientConfig.offhandHud, left, featureY + 24, columnWidth);
		addToggle("Armor HUD", "HUD", () -> ClientConfig.armorHud,
				() -> ClientConfig.armorHud = !ClientConfig.armorHud, left + columnWidth + gap, featureY + 24, columnWidth);
		addToggle("Status HUD", "HUD", () -> ClientConfig.statusHud,
				() -> ClientConfig.statusHud = !ClientConfig.statusHud, left, featureY + 48, columnWidth);
		addToggle("Potion HUD", "HUD", () -> ClientConfig.potionHud,
				() -> ClientConfig.potionHud = !ClientConfig.potionHud, left + columnWidth + gap, featureY + 48, columnWidth);
		addToggle("Supplies HUD", "HUD", () -> ClientConfig.suppliesHud,
				() -> ClientConfig.suppliesHud = !ClientConfig.suppliesHud, left, featureY + 72, columnWidth);
		addToggle("Toggle Sprint", "QoL", () -> ClientConfig.toggleSprint,
				() -> ClientConfig.toggleSprint = !ClientConfig.toggleSprint, left + columnWidth + gap, featureY + 72, columnWidth);
		addToggle("NoHurtCam", "Visual", () -> ClientConfig.noHurtCam,
				() -> ClientConfig.noHurtCam = !ClientConfig.noHurtCam, left, featureY + 96, columnWidth);
		addToggle("Death marker", "HUD", () -> ClientConfig.deathMarkerHud,
				() -> ClientConfig.deathMarkerHud = !ClientConfig.deathMarkerHud, left, featureY + 120, contentWidth);

		durabilityButton = addRenderableWidget(Button.builder(Component.literal("Durability settings"), button ->
				minecraft.gui.setScreen(new NotificationSettingsScreen(this)))
				.bounds(left + columnWidth + gap, featureY + 96, columnWidth, 20).build());
		featureWidgets.add(new FeatureWidget("Durability alert", "HUD", () -> false, () -> { }, durabilityButton));
		addToggle("Auto profile by dimension", "Profiles", () -> ClientConfig.autoHudProfileByDimension,
				() -> ClientConfig.autoHudProfileByDimension = !ClientConfig.autoHudProfileByDimension,
				left, featureY + 144, contentWidth);
		potionFilterButton = addRenderableWidget(Button.builder(potionFilterMessage(), button -> cyclePotionFilter())
				.bounds(left, featureY + 168, contentWidth, 20).build());
		featureWidgets.add(new FeatureWidget("Potion filter", "HUD", () -> false, () -> { }, potionFilterButton));
		addToggle("Death marker", "HUD", () -> ClientConfig.deathMarkerHud,
				() -> ClientConfig.deathMarkerHud = !ClientConfig.deathMarkerHud,
				left, featureY + 168, contentWidth);

		int sectionY = panelY + 342;
		profileButton = addRenderableWidget(Button.builder(profileMessage(), button -> cycleProfile())
				.bounds(left, sectionY, columnWidth, 22).build());
		saveProfileButton = addRenderableWidget(Button.builder(Component.literal("Save profile"), button -> {
			ClientConfig.saveHudProfile();
			button.setMessage(Component.literal("Profile saved"));
		}).bounds(left + columnWidth + gap, sectionY, columnWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Edit HUD layout"), button ->
				minecraft.gui.setScreen(new HudEditorScreen(this)))
				.bounds(left, sectionY + 29, contentWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Tracked items"), button ->
				minecraft.gui.setScreen(new ItemTrackerScreen(this)))
				.bounds(left, sectionY + 58, columnWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Alert settings"), button ->
				minecraft.gui.setScreen(new NotificationSettingsScreen(this)))
				.bounds(left + columnWidth + gap, sectionY + 58, columnWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Choose custom accent color"), button ->
				minecraft.gui.setScreen(new ColorPickerScreen(this)))
				.bounds(left, sectionY + 87, columnWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Profile backup"), button ->
				minecraft.gui.setScreen(new ProfileBackupScreen(this)))
				.bounds(left + columnWidth + gap, sectionY + 87, columnWidth, 22).build());

		addRenderableWidget(Button.builder(Component.literal("Close"), button -> onClose())
				.bounds(panelX + panelWidth / 2 - 55, panelY + panelHeight - 28, 110, 20).build());
		refreshCategoryButtons();
		refreshFeatureWidgets();
	}

	private void addToggle(String name, String category, BooleanSupplier enabled, Runnable toggle, int x, int y, int buttonWidth) {
		addRenderableWidget(Button.builder(toggleMessage(name, enabled.getAsBoolean()), button -> {
			toggle.run();
			button.setMessage(toggleMessage(name, enabled.getAsBoolean()));
			ClientConfig.save();
		}).bounds(x, y, buttonWidth, 20).build());
		Button featureButton = (Button) children().getLast();
		featureWidgets.add(new FeatureWidget(name, category, enabled, toggle, featureButton));
	}

	private void cycleProfile() {
		int current = 0;
		for (int index = 0; index < ClientConfig.HUD_PROFILE_NAMES.length; index++) {
			if (ClientConfig.HUD_PROFILE_NAMES[index].equals(ClientConfig.activeHudProfile)) {
				current = index;
				break;
			}
		}
		String next = ClientConfig.HUD_PROFILE_NAMES[(current + 1) % ClientConfig.HUD_PROFILE_NAMES.length];
		ClientConfig.loadHudProfile(next);
		profileButton.setMessage(profileMessage());
		saveProfileButton.setMessage(Component.literal("Save profile"));
		refreshFeatureWidgets();
	}

	private static Component profileMessage() {
		return Component.literal("Profile: " + ClientConfig.activeHudProfile);
	}

	private static Component durabilityMessage() {
		return Component.literal("Configure durability alerts");
	}

	private static Component potionFilterMessage() {
		return Component.literal("Potion filter: " + ClientConfig.potionFilter.name());
	}

	private void cyclePotionFilter() {
		ClientConfig.PotionFilter[] filters = ClientConfig.PotionFilter.values();
		int next = (ClientConfig.potionFilter.ordinal() + 1) % filters.length;
		ClientConfig.potionFilter = filters[next];
		potionFilterButton.setMessage(potionFilterMessage());
		ClientConfig.save();
	}

	private Component categoryMessage(String category) {
		return Component.literal((selectedCategory.equals(category) ? "[ " : "") + category
				+ (selectedCategory.equals(category) ? " ]" : ""));
	}

	private void refreshCategoryButtons() {
		for (int index = 0; index < categoryButtons.size(); index++) {
			categoryButtons.get(index).setMessage(categoryMessage(CATEGORIES[index]));
		}
	}

	private void refreshFeatureWidgets() {
		for (FeatureWidget widget : featureWidgets) {
			boolean categoryMatches = selectedCategory.equals("All") || selectedCategory.equals(widget.category());
			boolean searchMatches = widget.label().toLowerCase(Locale.ROOT).contains(searchQuery);
			widget.button().visible = categoryMatches && searchMatches;
			if (widget.label().equals("Potion filter")) {
				widget.button().setMessage(potionFilterMessage());
			} else if (!widget.label().equals("Durability alert")) {
				widget.button().setMessage(toggleMessage(widget.label(), widget.enabled().getAsBoolean()));
			} else {
				widget.button().setMessage(durabilityMessage());
			}
		}
	}

	private static Component toggleMessage(String name, boolean enabled) {
		return Component.literal(name + "   " + (enabled ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0x6A080D10);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, ClientConfig.accentColor);
		graphics.outline(panelX, panelY, panelWidth, panelHeight, 0xFF3B494B);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "OPTIC CLIENT", panelX + 20, panelY + 20, 0xFFF1F5F4, false);
		graphics.text(font, "CLIENT UTILITIES", panelX + 20, panelY + 39, 0xFF9EADAE, false);
		graphics.text(font, "FEATURES", panelX + 20, panelY + 96, ClientConfig.accentColor, false);
		graphics.text(font, "HUD PROFILE", panelX + 20, panelY + 331, ClientConfig.accentColor, false);
		graphics.text(font, "LAYOUT / TOOLS", panelX + 20, panelY + 361, ClientConfig.accentColor, false);
		graphics.fill(panelX + panelWidth - 44, panelY + 420, panelX + panelWidth - 32, panelY + 432, ClientConfig.accentColor);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(null);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}