package com.optic.client.gui;

import com.optic.client.config.ClientConfig;
import com.optic.client.hud.HudRenderer;
import com.optic.client.hud.HudRenderer.Bounds;
import com.optic.client.hud.HudRenderer.Element;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import com.mojang.blaze3d.platform.InputConstants;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.List;

public final class HudEditorScreen extends Screen {
	private final Screen parent;
	private Element selected = Element.STATUS;
	private final EnumSet<Element> selectedElements = EnumSet.of(Element.STATUS);
	private final EnumMap<Element, Bounds> dragStartBounds = new EnumMap<>(Element.class);
	private Element dragging;
	private double dragOffsetX;
	private double dragOffsetY;
	private Button targetButton;
	private Button lockButton;
	private Button snapButton;
	private int controlLeft;
	private int controlWidth;

	public HudEditorScreen(Screen parent) {
		super(Component.literal("HUD Layout Editor"));
		this.parent = parent;
	}

	public static Element selectedElement() {
		Screen screen = net.minecraft.client.Minecraft.getInstance().gui.screen();
		return screen instanceof HudEditorScreen editor ? editor.selected : null;
	}

	public static boolean isElementSelected(Element element) {
		Screen screen = net.minecraft.client.Minecraft.getInstance().gui.screen();
		return screen instanceof HudEditorScreen editor && editor.selectedElements.contains(element);
	}

	@Override
	protected void init() {
		clearWidgets();
		controlWidth = Math.min(432, width - 16);
		controlLeft = (width - controlWidth) / 2;
		int gap = 6;
		int columnWidth = (controlWidth - gap * 2) / 3;
		int firstRow = height - 110;
		int secondRow = height - 80;
		int thirdRow = height - 50;
		targetButton = addRenderableWidget(Button.builder(targetMessage(), button -> select(selected.next()))
				.bounds(controlLeft, firstRow, columnWidth, 22).build());
		addAdjustmentButton("Scale -", -0.1f, true, controlLeft + columnWidth + gap, firstRow, columnWidth);
		addAdjustmentButton("Scale +", 0.1f, true, controlLeft + (columnWidth + gap) * 2, firstRow, columnWidth);
		addAdjustmentButton("Opacity -", -0.1f, false, controlLeft, secondRow, columnWidth);
		addAdjustmentButton("Opacity +", 0.1f, false, controlLeft + columnWidth + gap, secondRow, columnWidth);
		addRenderableWidget(Button.builder(Component.literal("Done"), button -> onClose())
				.bounds(controlLeft + (columnWidth + gap) * 2, secondRow, columnWidth, 22).build());
		lockButton = addRenderableWidget(Button.builder(lockMessage(), button -> {
			ClientConfig.hudLocked = !ClientConfig.hudLocked;
			button.setMessage(lockMessage());
			ClientConfig.save();
		}).bounds(controlLeft, thirdRow, columnWidth, 22).build());
		snapButton = addRenderableWidget(Button.builder(snapMessage(), button -> {
			ClientConfig.snapHudToGrid = !ClientConfig.snapHudToGrid;
			button.setMessage(snapMessage());
			ClientConfig.save();
		}).bounds(controlLeft + columnWidth + gap, thirdRow, columnWidth, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Reset layout"), button -> {
			HudRenderer.resetLayouts();
			ClientConfig.saveHudProfile();
		}).bounds(controlLeft + (columnWidth + gap) * 2, thirdRow, columnWidth, 22).build());
		int nudgeWidth = (controlWidth - gap * 3) / 4;
		int nudgeY = height - 24;
		addNudgeButton("Move left", -8, 0, controlLeft, nudgeY, nudgeWidth);
		addNudgeButton("Move right", 8, 0, controlLeft + nudgeWidth + gap, nudgeY, nudgeWidth);
		addNudgeButton("Move up", 0, -8, controlLeft + (nudgeWidth + gap) * 2, nudgeY, nudgeWidth);
		addNudgeButton("Move down", 0, 8, controlLeft + (nudgeWidth + gap) * 3, nudgeY, nudgeWidth);
	}

	private void addAdjustmentButton(String label, float delta, boolean scale, int x, int y, int buttonWidth) {
		addRenderableWidget(Button.builder(Component.literal(label), button -> {
			if (scale) HudRenderer.adjustScale(selected, delta);
			else HudRenderer.adjustOpacity(selected, delta);
			ClientConfig.save();
		}).bounds(x, y, buttonWidth, 22).build());
	}

	private void addNudgeButton(String label, int deltaX, int deltaY, int x, int y, int buttonWidth) {
		addRenderableWidget(Button.builder(Component.literal(label), button -> {
			moveSelectedGroupBy(deltaX, deltaY);
			ClientConfig.saveHudProfile();
		}).bounds(x, y, buttonWidth, 20).build());
	}

	private void select(Element element) {
		selected = element;
		selectedElements.clear();
		selectedElements.add(element);
		if (targetButton != null) targetButton.setMessage(targetMessage());
	}

	private void toggleSelection(Element element) {
		selected = element;
		if (!selectedElements.add(element) && selectedElements.size() > 1) {
			selectedElements.remove(element);
		}
		if (selectedElements.isEmpty()) selectedElements.add(element);
		if (targetButton != null) targetButton.setMessage(targetMessage());
	}

	private void moveSelectedGroupBy(int deltaX, int deltaY) {
		for (Element element : selectedElements) {
			HudRenderer.moveBy(element, deltaX, deltaY, width, height);
		}
	}

	private void moveSelectedGroupTo(int x, int y) {
		Bounds origin = dragStartBounds.get(dragging);
		if (origin == null) return;
		int deltaX = x - origin.x();
		int deltaY = y - origin.y();
		for (var entry : dragStartBounds.entrySet()) {
			Bounds bounds = entry.getValue();
			HudRenderer.setPosition(entry.getKey(), bounds.x() + deltaX, bounds.y() + deltaY, width, height);
		}
	}

	private Component targetMessage() {
		return Component.literal("Selected: " + selected.name());
	}

	private static Component lockMessage() {
		return Component.literal("HUD lock: " + (ClientConfig.hudLocked ? "ON" : "OFF"));
	}

	private static Component snapMessage() {
		return Component.literal("Grid snap: " + (ClientConfig.snapHudToGrid ? "ON" : "OFF"));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
		if (event.button() == 0) {
			boolean onControls = event.x() >= controlLeft - 4 && event.x() <= controlLeft + controlWidth + 4
					&& event.y() >= height - 154;
			if (onControls) return super.mouseClicked(event, doubleClick);
			for (Element element : Element.values()) {
				Bounds bounds = HudRenderer.getBounds(element, width, height);
				if (bounds.contains(event.x(), event.y())) {
					if ((event.modifiers() & InputConstants.MOD_SHIFT) != 0) toggleSelection(element);
					else select(element);
					if (!ClientConfig.hudLocked) {
						dragging = element;
						dragOffsetX = event.x() - bounds.x();
						dragOffsetY = event.y() - bounds.y();
						dragStartBounds.clear();
						for (Element selectedElement : selectedElements) {
							dragStartBounds.put(selectedElement, HudRenderer.getBounds(selectedElement, width, height));
						}
					}
					return true;
				}
			}
			return super.mouseClicked(event, doubleClick);
		}
		return super.mouseClicked(event, doubleClick);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
		if (dragging != null && event.button() == 0) {
			moveSelectedGroupTo((int) Math.round(event.x() - dragOffsetX), (int) Math.round(event.y() - dragOffsetY));
			return true;
		}
		return super.mouseDragged(event, dragX, dragY);
	}

	@Override
	public void mouseMoved(double mouseX, double mouseY) {
		if (dragging != null) {
			moveSelectedGroupTo((int) Math.round(mouseX - dragOffsetX), (int) Math.round(mouseY - dragOffsetY));
			return;
		}
		super.mouseMoved(mouseX, mouseY);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent event) {
		if (dragging != null && event.button() == 0) {
			dragging = null;
			dragStartBounds.clear();
			ClientConfig.save();
			return true;
		}
		return super.mouseReleased(event);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, width, height, 0x33040A0C);
		if (dragging != null) {
			Bounds bounds = HudRenderer.getBounds(dragging, width, height);
			List<Integer> verticalGuides = new ArrayList<>(List.of(width / 2, 8, width - 8));
			List<Integer> horizontalGuides = new ArrayList<>(List.of(height / 2, 8, height - 8));
			for (int guideX : verticalGuides) {
				if (Math.abs(bounds.x() - guideX) <= 5 || Math.abs(bounds.x() + bounds.width() - guideX) <= 5
						|| Math.abs(bounds.x() + bounds.width() / 2 - guideX) <= 5) {
					graphics.fill(guideX, 0, guideX + 1, height, 0xAAB5FFF4);
				}
			}
			for (int guideY : horizontalGuides) {
				if (Math.abs(bounds.y() - guideY) <= 5 || Math.abs(bounds.y() + bounds.height() - guideY) <= 5
						|| Math.abs(bounds.y() + bounds.height() / 2 - guideY) <= 5) {
					graphics.fill(0, guideY, width, guideY + 1, 0xAAB5FFF4);
				}
			}
		}
		graphics.fill(controlLeft - 4, height - 154, controlLeft + controlWidth + 4, height, 0xD90B1115);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, ClientConfig.hudLocked ? "HUD LAYOUT LOCKED" : "SHIFT-CLICK TO GROUP / DRAG TO MOVE",
				12, 12, 0xFFF2F5F4, false);
		graphics.text(font, "Selected: " + selectedElements.size() + " HUD elements", 12, 25, 0xFFF2F5F4, false);
		graphics.text(font, String.format("Scale %.1f   Opacity %d%%", HudRenderer.getScale(selected),
				Math.round(HudRenderer.getOpacity(selected) * 100)), 12, 38, ClientConfig.accentColor, false);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}