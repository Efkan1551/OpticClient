package com.optic.client.gui;

import com.optic.client.config.ClientConfig;
import com.optic.client.hud.HudAnchor;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public final class NotificationSettingsScreen extends Screen {
	private final Screen parent;
	private int panelX;
	private int panelY;
	private int panelWidth;
	private int panelHeight;

	public NotificationSettingsScreen(Screen parent) {
		super(Component.literal("Notification Settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		clearWidgets();
		panelWidth = Math.min(440, width - 24);
		panelHeight = Math.min(280, height - 24);
		panelX = (width - panelWidth) / 2;
		panelY = Math.max(12, (height - panelHeight) / 2);
		int left = panelX + 20;
		int gap = 4;
		int half = (panelWidth - 44) / 2;

		addThresholdButton("Mainhand", () -> ClientConfig.mainhandWarningPercent,
				value -> ClientConfig.mainhandWarningPercent = value, left, panelY + 54, half);
		addThresholdButton("Offhand", () -> ClientConfig.offhandWarningPercent,
				value -> ClientConfig.offhandWarningPercent = value, left + half + gap, panelY + 54, half);
		addThresholdButton("Helmet", () -> ClientConfig.helmetWarningPercent,
				value -> ClientConfig.helmetWarningPercent = value, left, panelY + 80, half);
		addThresholdButton("Chestplate", () -> ClientConfig.chestplateWarningPercent,
				value -> ClientConfig.chestplateWarningPercent = value, left + half + gap, panelY + 80, half);
		addThresholdButton("Leggings", () -> ClientConfig.leggingsWarningPercent,
				value -> ClientConfig.leggingsWarningPercent = value, left, panelY + 106, half);
		addThresholdButton("Boots", () -> ClientConfig.bootsWarningPercent,
				value -> ClientConfig.bootsWarningPercent = value, left + half + gap, panelY + 106, half);

		addRenderableWidget(Button.builder(durationMessage(), button -> {
			ClientConfig.notificationDurationSeconds = ClientConfig.notificationDurationSeconds >= 12
					? 2 : ClientConfig.notificationDurationSeconds + 2;
			button.setMessage(durationMessage());
			ClientConfig.save();
		}).bounds(left, panelY + 144, half, 22).build());
		addRenderableWidget(Button.builder(positionMessage(), button -> {
			ClientConfig.notificationPosition = ClientConfig.notificationPosition.next();
			button.setMessage(positionMessage());
			ClientConfig.save();
		}).bounds(left + half + gap, panelY + 144, half, 22).build());
		addRenderableWidget(Button.builder(heldMessage(), button -> {
			ClientConfig.durabilityAlertsHeldItems = !ClientConfig.durabilityAlertsHeldItems;
			button.setMessage(heldMessage());
			ClientConfig.save();
		}).bounds(left, panelY + 176, half, 22).build());
		addRenderableWidget(Button.builder(armorMessage(), button -> {
			ClientConfig.durabilityAlertsArmor = !ClientConfig.durabilityAlertsArmor;
			button.setMessage(armorMessage());
			ClientConfig.save();
		}).bounds(left + half + gap, panelY + 176, half, 22).build());
		addRenderableWidget(Button.builder(Component.literal("Back"), button -> onClose())
				.bounds(panelX + panelWidth / 2 - 55, panelY + 224, 110, 22).build());
	}

	private void addThresholdButton(String name, IntSupplier get, IntConsumer set, int x, int y, int buttonWidth) {
		addRenderableWidget(Button.builder(thresholdMessage(name, get.getAsInt()), button -> {
			int next = get.getAsInt() >= 100 ? 10 : get.getAsInt() + 10;
			set.accept(next);
			button.setMessage(thresholdMessage(name, next));
			ClientConfig.save();
		}).bounds(x, y, buttonWidth, 22).build());
	}

	private static Component thresholdMessage(String name, int threshold) {
		return Component.literal(name + " < " + threshold + "%");
	}

	private static Component durationMessage() {
		return Component.literal("Duration " + ClientConfig.notificationDurationSeconds + "s");
	}

	private static Component positionMessage() {
		return Component.literal("Position " + ClientConfig.notificationPosition.name().replace('_', ' '));
	}

	private static Component heldMessage() {
		return Component.literal("Hand alerts " + (ClientConfig.durabilityAlertsHeldItems ? "ON" : "OFF"));
	}

	private static Component armorMessage() {
		return Component.literal("Armor alerts " + (ClientConfig.durabilityAlertsArmor ? "ON" : "OFF"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		graphics.fill(0, 0, width, height, 0x99050A0D);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xF20B1115);
		graphics.fill(panelX, panelY, panelX + panelWidth, panelY + 3, ClientConfig.accentColor);
		graphics.outline(panelX, panelY, panelWidth, panelHeight, 0xFF3B494B);
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		graphics.text(font, "PER-SLOT DURABILITY ALERTS", panelX + 20, panelY + 22, 0xFFF2F5F4, false);
	}

	@Override
	public void onClose() {
		ClientConfig.save();
		minecraft.gui.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}